package com.springhow.examples.springboot.thymeleaf.crud.domain.entities;

public enum Role {
    Teacher,
    Student,
    Admin
}
